package com.JavaV.demo.service;

import com.JavaV.demo.model.TablePlayer;
import com.JavaV.demo.repository.DAOTablePlayer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@AllArgsConstructor
public class TablePlayerImpl implements TablePlayerService
{
    private final DAOTablePlayer daoTablePlayer;
    @Override
    public TablePlayer creer(TablePlayer tablePlayer) {
        return daoTablePlayer.save(tablePlayer);
    }

    @Override
    public List<TablePlayer> getAllTablePlayer() {
        return daoTablePlayer.findAll();
    }

    @Override
    public TablePlayer modify(long id, TablePlayer tablePlayer) {
        return daoTablePlayer.findById(id)
                .map(p-> {
                    p.setTables(tablePlayer.getTables());
                    p.setPlayers(tablePlayer.getPlayers());

                    return daoTablePlayer.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String delete(long id) {
        daoTablePlayer.deleteById(id);
        return "produit supprimé";
    }
}
