package com.JavaV.demo.controller;

import com.JavaV.demo.model.Tables;
import com.JavaV.demo.repository.DAOTable;
import com.JavaV.demo.service.TablesService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
@AllArgsConstructor
@RestController
@RequestMapping("/Tables")
public class TableController
{
    private final TablesService tablesService;
    //http://localhost:8080/Tables/createTable
    @PostMapping("/create")
    public Tables createTable(@RequestBody Tables table)
    {
        return tablesService.creer(table);
    }

    //http://localhost:8080/Tables/getAllTables
    @GetMapping("/getAll")
    public List<Tables> getAllTables()
    {
        return tablesService.getAllTables();
    }

    //http://localhost:8080/Tables/deleteTable/{id}
    @DeleteMapping("/delete/{id}")
    public String deleteTable(@PathVariable long id)
    {
        tablesService.delete(id);
        return "table deleted";
    }
    //http://localhost:8080/Addresses/modifyAddress/{id}
    @PutMapping("/modify/{id}")
    public Tables modifyTable(@PathVariable long id, @RequestBody Tables table)
    {
        return tablesService.modify(id, table);
    }
}
