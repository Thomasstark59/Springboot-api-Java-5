package com.JavaV.demo.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "PLAYERS")
@Getter
@Setter
@NoArgsConstructor
public class Players
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String surname;
    private String email;
    @OneToMany(mappedBy="id")
    private Set<Addresses> addresses;
}
