package com.JavaV.demo.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "ADDRESSES")
@Getter
@Setter
@NoArgsConstructor
public class Addresses
{
    @Id
    private long id;
    private String street;
    private int number;
    private String postal;
    private String agglo;

}
