package com.JavaV.demo.service;

import com.JavaV.demo.model.Tables;
import com.JavaV.demo.repository.DAOTable;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class TablesServiceImpl implements TablesService
{
    private final DAOTable daoTable;
    @Override
    public Tables creer(Tables tables) {
        return daoTable.save(tables);
    }

    @Override
    public List<Tables> getAllTables() {
        return daoTable.findAll();
    }

    @Override
    public Tables modify(long id, Tables tables) {
        return daoTable.findById(id)
                .map(p-> {
                    p.setName(tables.getName());
                    p.setDate(tables.getDate());
                    p.setAddresses(tables.getAddresses());
                    p.setMaxPlayerCount(tables.getMaxPlayerCount());
                    p.setRules(tables.getRules());

                    return daoTable.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String delete(long id) {
        daoTable.deleteById(id);
        return "produit supprimé";
    }
}
