package com.JavaV.demo.service;


import com.JavaV.demo.model.Addresses;
import com.JavaV.demo.model.Players;

import java.util.List;

public interface AddressServive
{
    Addresses creer (Addresses addresses);
    List<Addresses> getAllAddresses();
    Addresses modify(long id, Addresses addresses);
    String delete (long id);
}
