package com.JavaV.demo.controller;


import com.JavaV.demo.model.TablePlayer;
import com.JavaV.demo.service.TablePlayerService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Service
@AllArgsConstructor
@RestController
@RequestMapping("/TablePlayer")
public class TablePlayerController
{
    private final TablePlayerService tablePlayerService;
    //http://localhost:8080/Tables/createTable
    @PostMapping("/create")
    public TablePlayer createTablePlayer(@RequestBody TablePlayer tablePlayer)
    {
        return tablePlayerService.creer(tablePlayer);
    }

    //http://localhost:8080/Tables/getAllTables
    @GetMapping("/getAll")
    public List<TablePlayer> getAllTablePlayer()
    {
        return tablePlayerService.getAllTablePlayer();
    }

    //http://localhost:8080/Tables/deleteTable/{id}
    @DeleteMapping("/delete/{id}")
    public String deleteTablePlayer(@PathVariable long id)
    {
        tablePlayerService.delete(id);
        return "table deleted";
    }
    //http://localhost:8080/Addresses/modifyAddress/{id}
    @PutMapping("/modify/{id}")
    public TablePlayer modifyTablePlayer(@PathVariable long id, @RequestBody TablePlayer tablePlayer)
    {
        return tablePlayerService.modify(id, tablePlayer);
    }
}
