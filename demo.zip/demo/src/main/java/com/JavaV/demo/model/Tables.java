package com.JavaV.demo.model;

import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Entity
@Table(name = "TABLES")
@Getter
@Setter
@NoArgsConstructor
public class Tables
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String date;
    private int maxPlayerCount;
    private boolean is_Archived;
    @OneToOne(cascade = CascadeType.ALL)
    @MapsId
    private Addresses addresses;

    @OneToOne(cascade = CascadeType.ALL)
    @MapsId
    private Players players;

    @OneToMany(mappedBy="id")
    private Set<Rules> rules;

}
