package com.JavaV.demo.model;

import javax.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Entity
@Table(name = "TABLEUSER")
@Getter
@Setter
@NoArgsConstructor
public class TablePlayer
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @OneToOne(cascade = CascadeType.ALL)
    @MapsId
    private Tables tables;
    @OneToMany(mappedBy="id")
    private Set<Players> players;

}
