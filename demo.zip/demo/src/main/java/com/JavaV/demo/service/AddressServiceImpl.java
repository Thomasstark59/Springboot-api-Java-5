package com.JavaV.demo.service;

import com.JavaV.demo.model.Addresses;
import com.JavaV.demo.model.Players;
import com.JavaV.demo.repository.DAOAddress;
import com.JavaV.demo.repository.DAOPlayer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@AllArgsConstructor
public class AddressServiceImpl implements AddressServive
{
    private final DAOAddress daoAddress;
    @Override
    public Addresses creer(Addresses addresses) {
        return daoAddress.save(addresses);
    }

    @Override
    public List<Addresses> getAllAddresses() {
        return daoAddress.findAll();
    }

    @Override
    public Addresses modify(long id, Addresses addresses)
    {
        return daoAddress.findById(id)
                .map(p->
                {
                    p.setPostal(addresses.getPostal());
                    p.setNumber(addresses.getNumber());
                    p.setStreet(addresses.getStreet());
                    p.setAgglo(addresses.getAgglo());

                    return daoAddress.save(p);
                }.orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String delete(long id) {
        daoAddress.deleteById(id);
        return "produit supprimé";
    }
}
