package com.JavaV.demo.service;

import com.JavaV.demo.model.Players;
import com.JavaV.demo.repository.DAOPlayer;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class PlayerServiceImpl implements PlayerService
{
    private final DAOPlayer daoPlayer;
    @Override
    public Players creer(Players tables) {
        return daoPlayer.save(tables);
    }

    @Override
    public List<Players> getAllPlayers() {
        return daoPlayer.findAll();
    }

    @Override
    public Players modify(long id, Players players) {
        return daoPlayer.findById(id)
                .map(p-> {
                    p.setName(players.getName());
                    p.setSurname(players.getSurname());
                    p.setAddresses(players.getAddresses());
                    p.setEmail(players.getEmail());

                    return daoPlayer.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String delete(long id) {
        daoPlayer.deleteById(id);
        return "produit supprimé";
    }

}
