package com.JavaV.demo.service;

import com.JavaV.demo.model.Rules;

import java.util.List;

public interface RulesService
{
    Rules creer (Rules rules);
    List<Rules> getAllRules();
    Rules modify(long id, Rules rules);
    String delete (long id);
}
