package com.JavaV.demo.service;

import com.JavaV.demo.model.Rules;
import com.JavaV.demo.model.Tables;
import com.JavaV.demo.repository.DAORule;
import com.JavaV.demo.repository.DAOTable;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class RulesServiceImpl implements RulesService
{
    private final DAORule daoRule;
    @Override
    public Rules creer(Rules rules) {
        return daoRule.save(rules);
    }

    @Override
    public List<Rules> getAllRules() {
        return daoRule.findAll();
    }

    @Override
    public Rules modify(long id, Rules rules) {
        return daoRule.findById(id)
                .map(p-> {
                    p.setName(rules.getName());
                    p.setEdition(rules.getEdition());

                    return daoRule.save(p);
                }).orElseThrow(() -> new RuntimeException("produit non trouvé"));
    }

    @Override
    public String delete(long id) {
        daoRule.deleteById(id);
        return "produit supprimé";
    }
}
