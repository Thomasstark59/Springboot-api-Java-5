package com.JavaV.demo.service;


import com.JavaV.demo.model.TablePlayer;

import java.util.List;

public interface TablePlayerService
{
    TablePlayer creer (TablePlayer tablePlayer);
    List<TablePlayer> getAllTablePlayer();
    TablePlayer modify(long id, TablePlayer tablePlayer);
    String delete (long id);
}
