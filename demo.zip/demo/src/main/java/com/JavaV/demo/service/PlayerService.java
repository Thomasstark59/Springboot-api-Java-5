package com.JavaV.demo.service;


import com.JavaV.demo.model.Players;

import java.util.List;

public interface PlayerService
{
    Players creer (Players players);
    List<Players> getAllPlayers();
    Players modify(long id, Players players);
    String delete (long id);
}
