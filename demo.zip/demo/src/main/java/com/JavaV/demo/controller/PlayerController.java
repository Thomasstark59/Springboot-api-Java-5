package com.JavaV.demo.controller;

import com.JavaV.demo.model.Players;
import com.JavaV.demo.service.PlayerService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
@AllArgsConstructor
@RestController
@RequestMapping("/players")
public class PlayerController
{
    private final PlayerService playerService;
    //http://localhost:8080/players/createPlayer
    @PostMapping("/create")
    public Players createPlayer(@RequestBody Players players)
    {
        return playerService.creer(players);
    }

    //http://localhost:8080/players/getAllPlayer
    @GetMapping("/getAll")
    public List<Players> getAllPlayer()
    {
        return playerService.getAllPlayers();
    }

    //http://localhost:8080/players/deletePlayer/{id}
    @DeleteMapping("/delete/{id}")
    public String deletePlayer(@PathVariable long id)
    {
        playerService.delete(id);
        return "player deleted";
    }
    //http://localhost:8080/players/modifyPlayer/{id}
    @PutMapping("/modify/{id}")
    public Players modifyPlayer(@PathVariable long id, @RequestBody Players players)
    {
        return playerService.modify(id, players);
    }
}
