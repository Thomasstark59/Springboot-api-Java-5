package com.JavaV.demo.service;

import com.JavaV.demo.model.Tables;

import java.util.List;

public interface TablesService
{
    Tables creer (Tables tables);
    List<Tables> getAllTables();
    Tables modify(long id, Tables tables);
    String delete (long id);
}
