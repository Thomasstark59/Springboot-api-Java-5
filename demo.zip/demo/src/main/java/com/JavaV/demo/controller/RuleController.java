package com.JavaV.demo.controller;

import com.JavaV.demo.model.Rules;
import com.JavaV.demo.repository.DAORule;
import com.JavaV.demo.service.RulesService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
@AllArgsConstructor
@RestController
@RequestMapping("/Rules")
public class RuleController
{
    private final RulesService rulesService;
    //http://localhost:8080/Rules/createRule
    @PostMapping("/create")
    public Rules createRule(@RequestBody Rules rules)
    {
        return rulesService.creer(rules);
    }

    //http://localhost:8080/Rules/getAllRules
    @GetMapping("/getAll")
    public List<Rules> getAllRules()
    {
        return rulesService.getAllRules();
    }

    //http://localhost:8080/Rules/deleteRule/{id}
    @DeleteMapping("/delete/{id}")
    public String deleteRule(@PathVariable long id)
    {
        rulesService.delete(id);
        return "rule deleted";
    }
    //http://localhost:8080/Rules/modifyRule/{id}
    @PutMapping("/modify/{id}")
    public Rules modifyRule(@PathVariable long id, @RequestBody Rules rules)
    {
        return rulesService.modify(id, rules);
    }
}
