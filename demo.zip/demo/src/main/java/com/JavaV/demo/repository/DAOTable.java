package com.JavaV.demo.repository;

import com.JavaV.demo.model.Tables;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DAOTable extends JpaRepository<Tables, Long> {
}
