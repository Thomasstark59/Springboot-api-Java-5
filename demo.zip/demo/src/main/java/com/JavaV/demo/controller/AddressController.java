package com.JavaV.demo.controller;

import com.JavaV.demo.model.Addresses;
import com.JavaV.demo.service.AddressServive;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
@AllArgsConstructor
@RestController
@RequestMapping("/Addresses")
public class AddressController
{
    private final AddressServive addressServive;
    //http://localhost:8080/Addresses/createAddress
    @PostMapping("/createAddress")
    public Addresses createAddress(@RequestBody Addresses addresses)
    {
        return addressServive.creer(addresses);
    }

    //http://localhost:8080/Addresses/getAllAddresses
    @GetMapping("/getAllAddresses")
    public List<Addresses> getAllAddress()
    {
        return addressServive.getAllAddresses();
    }

    //http://localhost:8080/Addresses/deleteAddress/{id}
    @DeleteMapping("/deleteAddress/{id}")
    public String deleteAddress(@PathVariable long id)
    {
        addressServive.delete(id);
        return "address deleted";
    }
    //http://localhost:8080/Addresses/modifyAddress/{id}
    @PutMapping("/modifyAddress/{id}")
    public Addresses modifyAddress(@PathVariable long id, @RequestBody Addresses addresses)
    {
        return addressServive.modify(id, addresses);

    }
}
